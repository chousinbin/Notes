# DLUT-Beamer-Theme

Hurry up STAR and FORK this Repo, which is a free Gospel of dlut students, is the visual enjoyment and aesthetic impact for teachers. Using this template, you will easily enter the winner group of lives. And any report or defence will bow down on your crumpled jeans/garments from now on.

[click here to preview](https://github.com/fuujiro/DLUT-Beamer-Slide-V2/blob/master/slide.pdf)

### This template is suitable for:
- Undergraduate, postgraduate and doctoral thesis/dissertation defense
- Various academic reports and international conferences
- Club activities and class activities
- Wooing your favorite little brother(s)/sister(s)

### To use this template, you need:
- A little bit of programming skills
- A little bit of LaTeX experience
- Dare to lose face

### I prepared this for you：
Unlike other templates, you will no longer need to master MakeFile to write complex compiler, since I have already encapsulated the compileing process in the make.bat file. Windows users can enjoy the silky building experience with just a gentle click.
Those who use Mac OS, Linux, and other unix-like systems can now enjoy the same joy, since the make.sh file prepared for you is ready to go.

### License
[the GPL - 3.0 © fuujiro](https://github.com/fuujiro/DLUT-Beamer-Slide-V2/blob/master/LICENSE)
